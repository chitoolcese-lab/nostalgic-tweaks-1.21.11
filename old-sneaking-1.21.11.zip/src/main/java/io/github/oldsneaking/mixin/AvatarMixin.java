package io.github.oldsneaking.mixin;

import net.minecraft.world.entity.Avatar;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Changes the eye height of a crouching player to the old sneak eye height.
 * Based on Nostalgic Tweaks (LGPL-3.0), PlayerMixin. In 1.21.9+ the method lives in Avatar.
 */
@Mixin(Avatar.class)
public abstract class AvatarMixin
{
    @Inject(method = "getDefaultDimensions", at = @At("RETURN"), cancellable = true)
    private void oldsneaking$modifyCrouchEyeHeight(Pose pose, CallbackInfoReturnable<EntityDimensions> callback)
    {
        if (pose != Pose.CROUCHING || !((Object) this instanceof Player))
            return;

        callback.setReturnValue(callback.getReturnValue().withEyeHeight(1.41F));
    }
}
