package io.github.oldsneaking.mixin;

import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Disables smooth sneaking (the camera drops instantly like in old versions).
 * Based on Nostalgic Tweaks (LGPL-3.0), CameraMixin.
 */
@Mixin(Camera.class)
public abstract class CameraMixin
{
    @Shadow private Entity entity;
    @Shadow private float eyeHeight;

    @Inject(method = "tick", at = @At("RETURN"))
    private void oldsneaking$onPostTick(CallbackInfo callback)
    {
        if (this.entity == null)
            return;

        float entityEyeHeight = this.entity.getEyeHeight();

        if (this.eyeHeight < entityEyeHeight)
            this.eyeHeight += (entityEyeHeight - this.eyeHeight) * 0.7F;
        else
            this.eyeHeight = entityEyeHeight;

        if (this.entity instanceof Player player && entityEyeHeight == 1.62F)
        {
            if (!player.getAbilities().flying && player.isCrouching())
                this.eyeHeight = 1.41F;
        }
    }
}
