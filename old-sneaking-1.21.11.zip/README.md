# Old Sneaking (Fabric 1.21.11)

Mod cliente que trae de vuelta el *old sneaking* de Nostalgic Tweaks: la cámara baja al instante al agacharte
y la altura de los ojos agachado es la antigua (1.41).

- Minecraft 1.21.11, Fabric Loader >= 0.18.0, Java 21. No necesita Fabric API.
- Sin menú ni config: siempre activo. Para desactivarlo, quita el .jar.

## Compilar
Sube el repo a GitHub: la pestaña **Actions** compila solo y deja el .jar en *Artifacts*.
En local: `gradle build` (Gradle 9.2+, JDK 21) -> `build/libs/old-sneaking-1.0.0.jar`.

## Créditos / licencia
Basado en el código de [Nostalgic Tweaks](https://github.com/Nostalgica-Reverie/Nostalgic-Tweaks) de Adrenix, LGPL-3.0-only.
